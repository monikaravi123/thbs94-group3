package com.torryharris.mvcdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.torryharris.mvcdemo.model.Product;
@Service
public interface ProductService {
	
	
	
void insertProduct(Product product);
	
	List<Product> getAllProduct();

}
